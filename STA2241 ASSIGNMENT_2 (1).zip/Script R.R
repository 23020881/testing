
 #23020881 & 23028631

  #5. Capturing Data in a Data Frame for 30 students
  
  Gender<-c("Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female", "Male", "Female") 
  Birthday<-c(10, 15, 23, 5, 28, 4, 12, 18, 9, 6, 22, 19, 1, 3, 17, 14, 11, 25, 16, 29, 7, 2, 13, 24, 21, 8, 20, 27, 30, 26)
  Birthmonth <-c(3, 7, 2, 12, 6, 9, 4, 8, 10, 1, 11, 5, 3, 6, 2, 7, 8, 9, 1, 10, 11, 4, 12, 5, 6, 7, 9, 8, 10, 2)
  Birthyear<-c(2005, 2002, 2001, 2003, 2004, 2005, 2000, 2004, 2003, 2000, 2002, 2005, 2003, 2002, 2003, 2001, 2000, 2004, 2005, 2001, 2000, 2001, 2002, 2004, 2002, 2000, 2003, 2004, 2001, 2003)
  Tribe<-c("Venda", "Pedi", "Tsonga", "Venda", "Other", "Tsonga", "Pedi", "Venda", "Other", "Pedi", "Venda", "Tsonga", "Other", "Venda", "Pedi", "Other", "Tsonga", "Venda", "Pedi", "Tsonga", "Venda", "Other", "Pedi", "Tsonga", "Other", "Venda", "Pedi", "Tsonga", "Venda", "Other")
  Height<-c(170, 165, 180, 175, 160, 170, 185, 150, 160, 175, 165, 170, 155, 180, 165, 175, 170, 160, 170, 150, 160, 165, 180, 175, 155, 170, 180, 160, 185, 170)
  Weight<-c(65, 55, 75, 70, 60, 72, 80, 50, 58, 68, 62, 66, 55, 80, 60, 75, 90, 55, 70, 52, 65, 60, 85, 77, 58, 65, 80, 72, 90, 67)
  Opinion<-c("Agree", "Disagree", "Agree", "Disagree", "Agree", "Disagree", "Disagree", "Agree", "Disagree", "Agree", "Disagree", "Agree", "Disagree", "Disagree", "Agree", "Disagree", "Agree", "Disagree", "Disagree", "Agree", "Disagree", "Agree", "Disagree", "Agree", "Disagree", "Agree", "Disagree", "Agree", "Disagree", "Agree")
  EnglishScore<-c(60, 70, 75, 80, 85, 70, 65, 78, 82, 75, 68, 72, 90, 85, 60, 65, 75, 68, 80, 85, 70, 65, 78, 82, 75, 68, 72, 90, 85, 60)
  MathsScore<-c(75, 80, 85, 90, 65, 70, 75, 80, 85, 90, 65, 70, 85, 90, 75, 80, 85, 70, 75, 65, 80, 75, 90, 85, 70, 75, 80, 85, 90, 65)
  LOScore<-c(85, 90, 70, 95, 88, 78, 85, 92, 90, 83, 88, 92, 70, 95, 88, 85, 90, 85, 70, 75, 95, 78, 88, 90, 92, 85, 70, 95, 88, 85)
  Data<-data.frame(Gender,Birthday,Birthmonth,Birthyear,Tribe,Height,Weight,Opinion,EnglishScore,MathsScore,LOScore)
  Data


# (a). Renaming Variables 
names(Data) <- c("Sex", "Bday", "Bmon", "Byear", "Tribe", "Hght", "Weght", "Opin", "Eng", "Mat", "LO")

# (b) Changing character variables to factors
Data$Sex <- as.factor(Data$Sex)
Data$Tribe <- as.factor(Data$Tribe)
Data$Opin <- as.factor(Data$Opin)

# (c) Calculating mean and standard deviation of heights
mean_height <- mean(Data$Hght)
mean_height
sd_height <- sd(Data$Hght)
sd_height

 #(d) Calculating the percentage below 160cm and above 180cm
#i.
p_below_160 <- pnorm(160, mean = mean_height, sd = sd_height)
p_below_160
#ii.
p_above_180 <- 1 - pnorm(180, mean = mean_height, sd = sd_height)
p_above_180

# iii. Finding height below which 30% of the population falls
height_30_percent <- qnorm(0.30, mean = mean_height, sd = sd_height)
height_30_percent

# iv. Simulating 50 height values
simulated_heights <- rnorm(50, mean = mean_height, sd = sd_height)
simulated_heights

# (e) Creating a new data frame "Newdf" consisting of only numeric variables and use sapply to find medians
Newdf <- Data[, sapply(Data, is.numeric)]
Newdf
medians <- sapply(Newdf, median)
medians

# (f) Using tapply to find the mean Life Orientation score by Tribe and Gender
mean_LO_by_tribe_gender <- tapply(Data$LO, list(Data$Tribe, Data$Sex), mean)
mean_LO_by_tribe_gender

# (g) Using aggregate to find mean scores for English, LO, and Mathematics by Gender
mean_scores_by_gender <- aggregate(cbind(Eng, LO, Mat) ~ Sex, data = Data, mean)
mean_scores_by_gender

# (h) Estimating the correlation between English and LO scores and test for significance
cor_test <- cor.test(Data$Eng, Data$LO)
cor_test

# (i) Performing a hypothesis test to check if all tribes are equally represented
chisq_test_tribes <- chisq.test(table(Data$Tribe))
chisq_test_tribes

# (j)  Testing if opinion on Venda difficulty is associated with Tribe
chisq_test_opinion_tribe <- chisq.test(table(Data$Opin, Data$Tribe))
chisq_test_opinion_tribe

# (k) Creating a new variable "Bday" in the form "dd/mm/YYYY"
Data$Bday <- as.Date(paste(Data$Byear, Data$Bmon, Data$Bday, sep = "-"))
Data$Bday

# (l) Adding an "Age" variable (current year - birth year)
Data$Age <- as.integer(format(Sys.Date(), "%Y")) - Data$Byear
Data$Age

# (m) Creating a "Trbyr" variable by combining tribe and birth year
Data$Trbyr <- paste(substr(as.character(Data$Tribe), 1, 3), Data$Byear, sep = "")
Data$Trbyr

# (n) Exporting the data frame to "final.csv"
write.csv(Data, "final.csv", row.names = FALSE)

# (o) Creating a boxplot of heights stratified by tribe
boxplot(Hght ~ Tribe, data = Data, main = "Height Distribution by Tribe", xlab = "Tribe", ylab = "Height (cm)")


    
    